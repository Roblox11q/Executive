# Stand Discord Config Bot (Render + Supabase)

**In-game support:** Da Hood (`2788229376`) · DERS HOOD (`96247461091106`) · Des Hood (`128413479081937`) · Hood Customs (`9825515356`)

## 1. Supabase

1. Create a project at https://supabase.com
2. SQL Editor -> run `supabase_schema.sql`
3. Project Settings -> API:
   - `SUPABASE_URL`
   - `SUPABASE_KEY` = **service_role** key (recommended for bots; bypasses RLS)

## 2. Render

1. New -> **Web Service** (not Web Service)
2. Connect your GitHub repo containing this folder
3. Build: `pip install -r requirements.txt`
4. Start: `python bot.py`
5. Environment variables:

| Key | Value |
|-----|--------|
| `DISCORD_TOKEN` | Bot token |
| `BUYER_ROLE_ID` | Discord role ID for buyers |
| `MAIN_SCRIPT_URL` | Raw GitHub URL to StandMain.lua |
| `SUPABASE_URL` | https://xxxx.supabase.co |
| `SUPABASE_KEY` | service_role key |

## 3. Discord

- Enable **Server Members Intent** in the developer portal (role checks)
- Invite with scopes: `bot`, `applications.commands`

## Commands

- `/setuploader` - set owner username
- `/addalt` / `/removealt` - link alts
- `/config` - gun, prefix, toggles
- `/mylinks` - list links
- `/unlink` - wipe config
- `/loader` - download personal StandLoader.lua (inject on **alts only**)
- `/addcontroller` / `/removecontroller` - extra Roblox users who can command alts

**Staff** (needs `STAFF_ROLE_ID`, or Administrator if `0`):
- `/blacklist` `/unblacklist` `/checkblacklist`
- `/forceunlink` `/staffview`

Only users with `BUYER_ROLE_ID` can use buyer commands (set `0` to allow all while testing).

**In-game:** inject on alts only. Owner (and controllers) type commands in public chat.


## Render free tier note

Use a **Web Service** (not Background Worker). The bot starts a tiny HTTP server on `PORT` so Render keeps the process alive. Open the service URL in a browser — you should see `Stand Discord bot online`.
